
-- the displayed name
title="WetDike"


-- the internal name, used for the base game module
name="dike"


