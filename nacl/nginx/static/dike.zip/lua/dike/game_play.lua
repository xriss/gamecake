-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local function dprint(a) print(wstr.dump(a)) end


module(...)
modname=(...)

bake=function(state,play)
	local play=play or {}
	play.state=state
	
	play.modname=modname
		
	local cards=state:rebake("dike.cards")
	local stacks=state:rebake("dike.stacks")
	local items=state:rebake("dike.items")
	
	
play.loads=function(state)
end
		
play.setup=function(state)
	local cake=state.cake

	play.loads(state)

local ppx=6
local ppy=6
local pcx=96
local pcy=136
	
	local stack
	play.stacks={}
	stack=stacks.create({px=ppx+(pcx/2),py=ppy+(pcy/2),form="pile",idx=1,name="deck"})
	stack:fill52()
	stack:shuffle()
	stack:setface(false)
	
	play.stacks[stack.idx]=stack
	play.stacks[stack.name]=stack

	stack=stacks.create({px=ppx+(pcx/2)+((ppx+pcx)*1),py=ppy+(pcy/2),form="side",idx=2,name="deal"})
	play.stacks[stack.idx]=stack
	play.stacks[stack.name]=stack
	
	stack=stacks.create({px=ppx+(pcx/2)+((ppx+pcx)*3),py=ppy+(pcy/2),form="pile",idx=3,name="away"})
	play.stacks[stack.idx]=stack
	stack=stacks.create({px=ppx+(pcx/2)+((ppx+pcx)*4),py=ppy+(pcy/2),form="pile",idx=4,name="away"})
	play.stacks[stack.idx]=stack
	stack=stacks.create({px=ppx+(pcx/2)+((ppx+pcx)*5),py=ppy+(pcy/2),form="pile",idx=5,name="away"})
	play.stacks[stack.idx]=stack
	stack=stacks.create({px=ppx+(pcx/2)+((ppx+pcx)*6),py=ppy+(pcy/2),form="pile",idx=6,name="away"})
	play.stacks[stack.idx]=stack

	for n=7,13 do
		stack=stacks.create({px=ppx+(pcx/2) + ((ppx+pcx)*(n-7)),py=ppy+(pcy/2)+ppy+pcy,form="down",idx=n,name="work"})
		play.stacks[stack.idx]=stack
		for _=1,n-6 do
			play.stacks.deck:move(stack,1)
		end
	end

	play.moves={} -- log the moves for undo or replay
	play.fliptops() -- this flips the top cards but also records the flipping
	play.moves={} -- so throw away initial flips and start again

	stack=stacks.create({form="hand",idx=14,name="hand"})
	play.stacks[stack.idx]=stack
	play.stacks[stack.name]=stack

	
end

play.clean=function(state)

end

-- make sure every card is the right way up
play.fliptops=function()
	for n=7,13 do
		stack=play.stacks[n]
		if #stack.cards>0 then
			if not stack.cards[#stack.cards].face then
				local mv={stack,stack,1} -- this is a flip
				play.moves[#play.moves+1]=mv
				stack.cards[#stack.cards].face=true
				stack.dirty=true
			end
		end
	end

	play.stacks.deck:setface(false) -- these are always this way up
	play.stacks.deal:setface(true)

end

-- is this a legal move? return num or an adjusted num if it is
play.check_move=function(mv)

	local frm=mv[1]
	local too=mv[2]
	local cnt=mv[3]


	if cnt>#frm.cards then cnt=#frm.cards end -- cards must exist
	if cnt<1 then mv[3]=0 return end -- must attempt a move

	
	if frm.name=="deck" and too.name=="deal" then -- deal
		cnt=#frm.cards
		if cnt>3 then cnt=3 end -- max deal of 3
		if cnt<1 then mv[3]=0 return end -- must have some cards
		mv[3]=cnt
		return mv
	end

	if frm.name=="deal" and too.name=="deck" then -- deal
		if #too.cards>0 then mv[3]=0 return end -- must be empty
		cnt=#frm.cards
		if cnt<1 then mv[3]=0 return end -- no cards to undeal
		mv[3]=cnt
		return mv
	end

	if too.name=="hand" then -- attempted pickup
	
		if #too.cards~=0 then mv[3]=0 end -- can not pickup if we are already holding some
	
		if frm.name=="deck" then mv[3]=0 return end -- cant grab from deck
		if frm.name=="deal" then mv[3]=1 return mv end -- can only grab top one from dealt cards
		if frm.name=="away" then mv[3]=1 return mv end -- can only grab top one from cards that have been put away
		if frm.name=="work" then -- can pick up only the top uncovered cards
			local i=0
			for j=#frm.cards,1,-1 do
				if frm.cards[j].face then i=i+1 else break end
			end
			if i==0 then mv[3]=0 return end
			if cnt>i then mv[3]=i end
			return mv
		end
	end

	if frm.name=="hand" then -- attempted putdown
	
		cnt=#frm.cards -- must place all cards

		if frm.lastmove==too then -- can always replace the cards we just picked up
			mv[3]=cnt -- all cards
			return mv
		end
		
		if too.name=="away" then
		
			if cnt~=1 then mv[3]=0 return end -- only one card at a time
			
			local c={cards.decode(frm.cards[1].code)} -- number,suit,color
			
			if #too.cards==0 then -- start with an ace
			
				if c[1]==1 then -- ace
					mv[3]=1
					return mv
				end
				
				mv[3]=0
				return
				
			else -- continue suit
			
				local t={cards.decode(too.cards[#too.cards].code)} -- number,suit,color
				if c[2] ~= t[2] then mv[3]=0 return end -- suits must match
				if c[1]==t[1]+1 then mv[3]=1 return mv end -- card must be next highest
				mv[3]=0
				return
				
			end
			
		elseif too.name=="work" then
		
			local c={cards.decode(frm.cards[1].code)} -- number,suit,color

			if #too.cards==0 then -- start with a king
			
				if c[1]==13 then -- king
					mv[3]=cnt
					return mv
				end
				
				mv[3]=0
				return
				
			else -- alternate color, continue 
			
				local t={cards.decode(too.cards[#too.cards].code)} -- number,suit,color
				if c[3] == t[3] then mv[3]=0 return end -- colors must not match
				if c[1]==t[1]-1 then mv[3]=cnt return mv end -- card must be next lowest
				mv[3]=0
				return
			end
		end
		
		
	end
	
	mv[3]=0 -- invalid move
	
end

play.msg=function(state,m)

--	print(wstr.dump(m))
	
	if m.class=="mouse" then
	
		play.over=nil
		
		for i,v in ipairs(play.stacks) do
			if i>=#play.stacks then break end -- last one is special hand
			if	v.bounds[1]<=m.x and
				v.bounds[2]<=m.y and
				v.bounds[3]>=m.x and
				v.bounds[4]>=m.y then
				play.over=v
				v.hover=0
				for i=#v.cards,1,-1 do
					local c=v.cards[i]
					if	v.px+c.px-(cards.hx/2) <= m.x and
						v.py+c.py-(cards.hy/2) <= m.y and
						v.px+c.px+(cards.hx/2) >= m.x and
						v.py+c.py+(cards.hy/2) >= m.y then
						v.hover=i
						break
					end
				end
			else
				v.hover=false
			end
		end

-- mouse down
		local mv

		if #play.stacks.hand.cards==0 then -- hand must be free
			if m.action==1 and m.keycode==1 then
				if play.over then
					if play.over.name=="deck" then
						if #play.over.cards==0 then -- return cards too the deck
							local count=#play.stacks.deal.cards
							if count>0 then
								mv={play.stacks.deal,play.stacks.deck,count}
							end
						else -- deal 3
							local count=#play.over.cards
							if count>3 then count=3 end
							mv={play.over,play.stacks.deal,count}
						end
					else
						local count=1
						if play.over.hover>0 then
							count=1+#play.over.cards-play.over.hover
						end
						if #play.stacks.hand.cards==0 then
							mv={play.over,play.stacks.hand,count}
						end
					end
				end
			end
		end

-- mouse up
		if m.action==-1 and m.keycode==1 then
			if play.over then
				if #play.stacks.hand.cards>0 then
					mv={play.stacks.hand,play.over,#play.stacks.hand.cards}
				end
			end
		end
		
		if mv then
			if mv[3]>0 then -- an attempted move
print(mv[1].name,mv[2].name,mv[3])
				play.check_move(mv)
print(mv[1].name,mv[2].name,mv[3])
				if mv[3]>0 then -- move is valid
					stacks.move(mv[1],mv[2],mv[3]) -- perform
					play.moves[#play.moves+1]=mv -- record

-- tidy up flipped cards
					if mv[2].name~="hand" then -- picking up doesnt flip anything
						play.fliptops()
					end
				end
			end
		end

		play.stacks.hand.px=m.x
		play.stacks.hand.py=m.y+(cards.hy/2)-12
		play.stacks.hand.dirty=true

--dprint(m)
		
	end
end

play.update=function(state)

	for i,v in ipairs(play.stacks) do
		v:update()
	end

end

play.draw=function(state)
--print("draw")
	local cake=state.cake
	local opts=state.opts
	local canvas=state.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=cake.gl


--[[
	for i=1,13 do
		cards.sheet("c",i):draw(1,20+((i-1)*90),100,0,80/100,115/144)
	end
]]
	
	for i=#play.stacks-1,1,-1 do local v=play.stacks[i]
		v:draw()
	end
	
	if play.over and #play.stacks.hand.cards>0 then -- show a ghost
		play.stacks.hand:draw(play.over)
	end
	
	play.stacks[#play.stacks]:draw()
	
end

	return play
end

