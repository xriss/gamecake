-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require


local function print(...) _G.print(...) end

local pack=require("wetgenes.pack")
local wstr=require("wetgenes.string")

module(...)
modname=(...)

bake=function(state,stacks)

	stacks=stacks or {} 
	stacks.modname=modname
	stacks.all={}
	
	local cards=state:rebake("dike.cards")
	local items=state:rebake("dike.items")

	local cake=state.cake
	local gl=cake.gl


	function stacks.create(opts) return stacks.setup(nil,opts) end
	function stacks.setup(stack,opts)
	
		stack=stack or {}
		stacks.all[stack]=true
		
		items.setup(stack,opts) -- set up position, etc
		
		stack.idx=opts.idx
		stack.name=opts.name
		stack.cards={} -- empty
		stack.form=opts.form or "down"
		stack.dirty=true
		
		for _,n in ipairs({
			"clean",
			"update",
			"draw",
			"setface",
			"fill52",
			"shuffle",
			"layout",
			"move",
		}) do
			stack[n]=stacks[n]
		end

		return stack
	end	

	function stacks.clean(stack)
	
		items.clean(stack)

		stacks.all[stack]=nil
		
	end

	function stacks.draw(stack,ghost)
		if ghost then
			gl.PushMatrix()
			
			gl.Translate(ghost.px+ghost.gx,ghost.py+ghost.gy,0)
			
			for i,v in ipairs(stack.cards) do
			
				gl.Color(pack.argb4_pmf4(0x8fff))
				v:draw()
			end
		
			gl.PopMatrix()
		else
			gl.PushMatrix()
			
			gl.Translate(stack.px,stack.py,0)
			
			for i,v in ipairs(stack.cards) do
			
--				if stack.hover and stack.hover<=i then
--					gl.Color(pack.argb4_pmf4(0xfccc))
--				else
					gl.Color(pack.argb4_pmf4(0xffff))
--				end
				
				v:draw()
			end
		
			gl.PopMatrix()
		end
	end
	
	
-- fill stack with 52 cards
	function stacks.setface(stack,face)
		for i,v in ipairs(stack.cards) do
			v.face=face
		end
	end

-- fill stack with 52 cards
	function stacks.fill52(stack)
		stack.cards={}
		for s=1,4 do
			for n=1,13 do
				stack.cards[#stack.cards+1]=cards.create({code=(s*100)+n})
			end
		end
	end

-- shuffle a pack of cards
	function stacks.shuffle(stack)
		function shuff(a,b)
			while #a>0 do
				b[#b+1]=table.remove(a,math.random(1,#a))
			end
		end
		local n={} -- tempory list
		shuff(stack.cards,n)
		shuff(n,stack.cards)
	end

-- layout a pack of cards if its flaged dirty
	function stacks.update(stack)
		if stack.dirty then
			stack:layout()
			stack.dirty=false
		end
	end

-- layout a pack of cards
	function stacks.layout(stack)
	
		stack.hx=0
		stack.hy=0
		stack.gx=0
		stack.gy=0

		function do_down()
			local d=24
			if #stack.cards>13 then
				d=(13*d)/#stack.cards
			end
			for i,v in ipairs(stack.cards) do
				v.px=0
				v.py=(i-1)*d
			end
			stack.gx=0
			stack.gy=#stack.cards*d
		end
	
		if stack.form=="pile" then
		
			for i,v in ipairs(stack.cards) do
				v.px=(i-1)*0.2
				v.py=(i-1)*-0.2
			end
			stack.gx=#stack.cards*0.2
			stack.gy=#stack.cards*-0.2

			
		elseif stack.form=="down" then

			do_down()

		elseif stack.form=="hand" then

			do_down()

		elseif stack.form=="side" then

			local d=24
			local px=6

			if #stack.cards>0 then
				for i,v in ipairs(stack.cards) do
					v.py=0
					v.px=0
					if i > #stack.cards-5 then
						v.px=px
						px=px+d
						if px>(6+96) then px=0 end
					end
				end
				stack.gx=stack.cards[#stack.cards].px
				stack.gy=stack.cards[#stack.cards].py
			end
			
		end
		
		if #stack.cards>0 then -- topcard is furthest away from base 0,0
			stack.hx=stack.cards[#stack.cards].px
			stack.hy=stack.cards[#stack.cards].py
		end
		
-- work out the bounds of this stack for mouse tests
		local p1={-96/2,-136/2,96/2,136/2}
		local p2={stack.hx,stack.hy,stack.hx,stack.hy}
		for i=1,4 do p2[i]=p2[i]+p1[i] end
		
		local p={ math.min(p1[1],p2[1]) , math.min(p1[2],p2[2]) , math.max(p1[3],p2[3]) , math.max(p1[4],p2[4]) }
		for i=1,4,2 do p[i]=p[i]+stack.px p[i+1]=p[i+1]+stack.py end
			
		stack.bounds=p
		
	end

-- move the top num cards from one stack to another
	function stacks.move(stack,too,num)
		if not num then return end -- calling with no args does nothing
		
		local c
		
		stack.dirty=true
		too.dirty=true
		
		local point=#stack.cards+1-num
		for i=1,num do
			if point>0 and point<=#stack.cards then
				c=table.remove(stack.cards,point)
				too.cards[#too.cards+1]=c
			end
		end
		
		too.lastmove=stack -- remember the last stack we moved from
				
		return c
	end
	
	return stacks
end

