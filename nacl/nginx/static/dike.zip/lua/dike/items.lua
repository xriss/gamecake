-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module(...)
modname=(...)

bake=function(state,items)

	items=items or {} 
	items.modname=modname
	items.all={}

	function items.create(opts) return items.setup(nil,opts) end
	function items.setup(item,opts)
	
		item=item or {}
		items.all[item]=true
	
		item.px=opts.px or 0
		item.py=opts.py or 0
			
		item.hx=opts.hx or 0
		item.hy=opts.hy or 0

		item.rz=opts.rz or 0

		return item
	end

	function items.clean(item)
	
		items.all[item]=nil
		
	end
	
	return items
end

