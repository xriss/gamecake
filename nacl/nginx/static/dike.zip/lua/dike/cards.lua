-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module(...)
modname=(...)

bake=function(state,cards)

	cards=cards or {} 
	cards.modname=modname

	cards.hx=96
	cards.hy=136
	
	local items=state:rebake("dike.items")

	
-- suit is a single letter from this list, or number if encoded in a single number
-- "b" 000 back of the card
-- "c" 100 clubs
-- "d" 200 diamonds
-- "h" 300 hearts
-- "s" 400 spades

	function cards.filename(suit,number)
		if type(suit)=="number" then -- decode a single code
			if suit>400 then		number=suit-400	suit="s"
			elseif suit>300 then	number=suit-300	suit="h"
			elseif suit>200 then	number=suit-200	suit="d"
			elseif suit>100 then	number=suit-100	suit="c"
			else					number=suit		suit="b"
			end
		end
		return string.format("cards/%s%02d",suit,number)
	end

	function cards.sheet(suit,number)
		return state.cake.sheets:get( cards.filename(suit,number) )
	end
	
	
	function cards.create(opts) return cards.setup(nil,opts) end
	function cards.setup(card,opts)
	
		card=card or {}
		card.code=opts.code or 1
		
		card.face=true -- face up
		
		items.setup(card,opts)
				
		for _,n in ipairs({
			"clean",
			"draw",
		}) do
			card[n]=cards[n]
		end

		return card
	end

	function cards.clean(card)
	
		items.clean(card)
		
	end

	function cards.decode(code)
		local number,suit,color
		if code>400 then		number=code-400	suit="s" color=1
		elseif code>300 then	number=code-300	suit="h" color=0
		elseif code>200 then	number=code-200	suit="d" color=0
		elseif code>100 then	number=code-100	suit="c" color=1
		else					number=code		suit="b" color=0
		end
		return number,suit,color
	end
	
	function cards.draw(card)
	
		if card.face then
		
			cards.sheet(card.code):draw(1,card.px,card.py,card.rz,96/100,136/142)
			
		else
		
			cards.sheet(2):draw(1,card.px,card.py,card.rz,96/100,136/142)
			
		end
	end


	return cards
end

