
-- the displayed name
title="bulb"


-- the internal name, used for the base game module
name="bulb"


