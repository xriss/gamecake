-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module("bulb.ball")

function bake(state,ball)
	local ball=ball or {}

	local cake=state.cake
	local game=cake.game	
	
	local input=state:rebake("bulb.input")
	local field	=state:rebake("bulb.field")
	local cells	=state:rebake("bulb.cells")
	local score	=state:rebake("bulb.score")
	

	function setup_nexts()
		local n={}
		ball.nexts=n
		
		for i=1,24 do
			n[#n+1]=math.random(1,6)
		end
		
		ball.next=1
	end
	
	function do_next()
		ball.id=ball.nexts[ ball.next ]
		ball.next=ball.next+1
		if ball.next>#ball.nexts then ball.next=1 end
	end
	
	function ball.setup_swing()
		local swing={}
		ball.swing=swing
		
		swing.cx=field.hx/2
		swing.cy=(game.unit/2)
		swing.loop=0 -- use a master loop
		swing.loop_max=60*3
		
		function swing.set()
			ball.px=swing.px
			ball.py=swing.py
			ball.vx=swing.vx
			ball.vy=swing.vy
			ball.rz=swing.rz
		end

		function swing.update()
				local swing=ball.swing
				
				swing.loop=swing.loop+1
				if swing.loop>=swing.loop_max then swing.loop=0 end
				
				local lx=swing.px or 0
				local ly=swing.py or 0

				local f=(swing.loop/swing.loop_max)
				
				swing.rz=90+( 90*math.abs(math.abs((f*4)-1)-2))
				
				swing.px=   (1/2)*(field.hx-game.unit*3)*math.sin(math.pi*2*f)
				swing.py= -game.unit - (3/16)*(field.hx-game.unit*3)*math.cos(math.pi*4*f)
				
				swing.px=-swing.px+swing.cx
				swing.py=-swing.py+swing.cy+ball.dip

				swing.vx=(swing.px-lx)*1
				swing.vy=(swing.py-ly)*1
				
				swing.dx= swing.cx-swing.px
				swing.dy= (swing.cy-game.unit*3)-swing.py
				
				local d=math.sqrt( swing.dx*swing.dx + swing.dy*swing.dy )
				if d<=0 then d=1 end
				swing.dx=swing.dx/d
				swing.dy=swing.dy/d
		end
		
		swing.update()
		swing.update()
		
		return swing	
	end
	
	function ball.state_change()

	-- handle state changes

		if ball.state_next then
		
			if ball.state and ball.state.clean then
				ball.state.clean()
			end
			
			if type(ball.state_next)=="string" then	 -- change by name
				ball.state_next=ball.states[ball.state_next]
			end

			ball.state_last=ball.state
			ball.state=ball.state_next
			ball.state_next=nil
			
			if ball.state and ball.state.setup then
				ball.state.setup()
			end
			
		end
		
	end

	ball.id=0

	ball.states={}
	ball.states.swing={
		setup=function()

			do_next()
			ball.sx=0
						
			ball.lazer={}
			ball.ghost_cell=nil
			
			ball.states.swing.update() -- fix the first bad velocity
		end,
		update=function()
		
			if ball.sx<1 then ball.sx=ball.sx+1/30 end
			if ball.sx>=1 then ball.sx=1 end
			
			ball.swing.set()

			if ball.count<32 then
				ball.build_lazer(32,2)
			end
			
			if input.button_down then
				ball.state_next="drop"
--print("down "..tostring(input.button_down))
			end
			
			local cx,cy=cells.pxy_to_cxy(ball.px,ball.py)
			local c=cells.get_cell(cx,cy)
			if cy<0 or ( c and c.id~=0 ) then
				game.state_next="menu"				
			end

		end,
	}
	ball.states.drop={
		setup=function()
			ball.lazer={}
			ball.ghost_cell=nil		
			ball.cell=nil
			ball.count=ball.count+1
			score.count=ball.count
			ball.dip=ball.dip+2
			ball.hits=0
--print("ballcount "..ball.count)
		end,
		update=function()
			local c=ball.fizix(ball)
			if c and ( c.id~=0 or c.cy==0 ) then -- lets call this a hit
--[[
				if c.id==2 and ball.hits==0 then -- bounce?
					ball.px=ball.px-ball.vx
					ball.py=ball.py-ball.vy
					ball.vx=ball.vx*-1.0
					ball.vy=ball.vy*-0.75
					ball.hits=1
--					ball.fizix(ball)
				else
]]				
					if c.id==0 and c.cy==0 then ball.cell=c end -- not a real hit
					if ball.cell then
						ball.cell.id=ball.id -- add it
						ball.cell.rz=ball.rz -- add it
	--					for c in ball.cell:neighbours() do
	--						c.id=ball.id -- add it
	--					end
						ball.cell.active=cells.frame -- flag as active this game frame
						ball.state_next="swing"
						cells.state_next="fall"
					else
						ball.state_next="swing"
	--print("failed to place ball")
					end
--				end
			else
				ball.cell=c or ball.cell -- only change if we have a new cell
			end
		end
	}
	ball.states.wait={
	}

	function ball.loads()
	end
	
	function ball.setup()
	
		ball.loads()

		
		ball.gravity=(game.unit*1/32)

		ball.dip=0
		ball.count=0
		
		setup_nexts()
		do_next()
		ball.sx=0
		
		ball.setup_swing()
		ball.swing.set()

		
		ball.state_next="swing"
		ball.state_change()
	end


	function ball.update()
		
		ball.swing.update()

		ball.state_change()	
		if ball.state and ball.state.update then ball.state.update() end	
		
	end

	function ball.draw()
	
		local bulbs=cake.sheets.get("bulbs")

		local s=math.floor(game.bulb_size/5)

		local a=0.5-(ball.count/64)
		if a>=0 then
			cake.gl.Color(a,a,a,a)
			for i=1,#ball.lazer,2 do
				local px=ball.lazer[i]
				local py=ball.lazer[i+1]

--				cake:blit("lazer",nil,
--					field.px+px-(s/2) , field.py+py-(s/2),
--					s*(ball.id-1),0,s,s )

				bulbs:draw(ball.id,field.px+px, field.py+py , ball.rz , 50/4)
			end
			if ball.ghost_cell then
				local px=ball.ghost_cell.px
				local py=ball.ghost_cell.py

--				cake:blit("bulbs",nil,
--					field.px+px-(game.bulb_size/2) , field.py+py-(game.bulb_size/2),
--					game.bulb_size*(ball.id-1),0,game.bulb_size,game.bulb_size )

				bulbs:draw(ball.id,field.px+px, field.py+py , ball.rz )

			end
		end
			
		cake.gl.Color(1,1,1,1)


		local z=(1-ball.sx)*30
		bulbs:draw(ball.id,field.px+ball.px +z*ball.swing.dx , field.py+ball.py +z*ball.swing.dy , ball.rz , 25 + ball.sx*25)
		
		local n=ball.next
		local id
		local function get_next_id()
			id=ball.nexts[n]
			n=n+1
			if n>#ball.nexts then n=1 return false end
			return true
		end
		
		local z=0
		if ball.sx<1 then
			z=20*(1-ball.sx)
		end
		z=z+30
		while get_next_id() do
			bulbs:draw(id,field.px+ball.swing.px+z*ball.swing.dx, field.py+ball.swing.py+z*ball.swing.dy , ball.swing.rz , 25)
			z=z+20
		end

	end

	function ball.build_lazer(count,pace)

		local it={}
		it.px=ball.px
		it.py=ball.py
		it.vx=ball.vx
		it.vy=ball.vy
		
		ball.lazer={}
		ball.ghost_cell=nil
		for i=1,count*pace do
			local c=ball.fizix(it)
			if c and c.id~=0 then return end
			if (i)%pace==0 then
				ball.lazer[#ball.lazer+1]=it.px
				ball.lazer[#ball.lazer+1]=it.py
			end
			ball.ghost_cell=c --rember the last free cell we passed through
			if c and c.cy==0 then return end
		end
		ball.ghost_cell=nil -- no collision

	end

	function ball.fizix(it)
	
		it.px=it.px+it.vx
		it.py=it.py+it.vy
		it.vy=it.vy+ball.gravity
		
		if it.px<game.unit*1.5 then
			it.px=game.unit*1.5 + ( game.unit*1.5 - it.px )
			if it.vx<0 then it.vx=-it.vx end
		end
		
		if it.px>field.hx-game.unit*1.5 then
			it.px=(field.hx-game.unit*1.5) - ( it.px - (field.hx-game.unit*1.5) )
			if it.vx>0 then it.vx=-it.vx end
		end


		local cx,cy=cells.pxy_to_cxy(it.px,it.py)
		if cy<0 then cy=0 end -- do not fall through bottom
		return cells.get_cell(cx,cy)
		
	end

	return ball
end
