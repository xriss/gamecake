-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(state,menu)
	local menu=menu or {}
	menu.state=state
	
	menu.modname=M.modname

	local cake=state.cake
	local sheets=cake.sheets
	local opts=state.opts
	local canvas=state.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=cake.gl
	
	local game=state:rebake("bulb.game")
	local gui=state:rebake("bulb.gui")

	local mods={} for i,n in ipairs{
--		"bulb.icles",
	} do mods[i]=state:rebake(n) end
	
--	local icles=state:rebake("bulb.icles")
	
menu.loads=function(state)

	sheets.loads_and_chops{
		{"game",1,1,0.5,0.5},
		{"bulbs",50/800,50/50,25/800,25/50},
	}
	
--[[
		cake.images.loads({
			"bulbs",
		})
		cake.sheets.create("bulbs"):setimg("bulbs"):chop(50/800,50/50,25/800,25/50)
]]

	for i,v in ipairs(mods) do
		if v.loads then v.loads() end
	end

end
		
menu.setup=function(state)


	for i,v in ipairs(mods) do
		if v.setup then v.setup() end
	end
	
--	icles.feathers.start()

	menu.loads(state)

	gui.page("menu")
		
end

menu.clean=function(state)

	for i,v in ipairs(mods) do
		if v.clean then v.clean() end
	end

end

menu.msg=function(state,m)

--	print(wstr.dump(m))

	if m.xraw and m.yraw then	-- we need to fix raw x,y numbers
		m.x,m.y=canvas.xyscale(m.xraw,m.yraw)	-- local coords, 0,0 is the center of screen
		m.x=m.x+(opts.width/2) -- origin is now top left of canvas view
		m.y=m.y+(opts.height/2)
	end
	
	if gui.msg(m) then return end -- gui can eat msgs
	
end

menu.update=function(state)

	local str=cake.sounds.strs[1]
	if not str.oggs then
		str.ogg_loop=true
		str.state="play_queue"
		str.oggs={
			"test",
		}
	end
	
	for i,v in ipairs(mods) do
		if v.update then v.update() end
	end

	gui.update()

end

menu.draw=function(state)
		
	sheets.get("game"):draw(1,320/2,480/2)
	
	for i,v in ipairs(mods) do
		if v.draw then v.draw() end
	end

	gui.draw()


	font.set(cake.fonts.get(1))
	font.set_size(32,0)
	
end

	return menu
end
