-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")


module("bulb.input")


function bake(state,input)
	local input=input or {}

	local cake=state.cake
	local game=state.game
	
	input.volatile=input.volatile or {}
	

	function input.loads()
	end
	
	function input.setup()
	
		input.loads()

		input.x=0
		input.y=0
		
		input.updated=0

	end

	function input.update_key(act,key,asc)
		if input.clear_count then print("ignoring key ",input.clear_count,act,asc,key) return end
		
		if act==1 then
			input.volatile.button=true
			input.volatile.button_down=true -- sticky flag
		end
		if act==-1 then
			if not input.volatile.button then --bug fix, android failed to send us a down...
				input.volatile.button=true
				input.volatile.button_down=true -- sticky flag
			end
			input.volatile.button=false
			input.volatile.button_up=true --sticky flag
		end

	end
	
	function input.update_mouse(act,x,y,key)
		if input.clear_count then print("ignoring mouse ",input.clear_count,act,x,y,key) return end
		
		input.updated=game.frame
	
		local screen=cake.canvas.win or {width=1,height=1}
		local w2=screen.width/2
		local h2=screen.height/2
		input.volatile.x=x
		input.volatile.y=y
		
		if act==1 then
			input.volatile.button=true
			input.volatile.button_down=true -- sticky flag
		end
		if act==-1 then
			if not input.volatile.button then --bug fix, android failed to send us a down...
				input.volatile.button=true
				input.volatile.button_down=true -- sticky flag
			end
			input.volatile.button=false
			input.volatile.button_up=true --sticky flag
		end
	end

	function input.update()
--print("update")
		-- volatile gets updated "whenever" so sample the current state for game code
		for i,v in pairs(input.volatile) do
			input[i]=v 
		end
		
		input.volatile.button_down=false
		input.volatile.button_up=false
		
		if input.clear_count then
			input.clear_count=input.clear_count-1
			if input.clear_count <= 0 then
				input.clear_count=nil
			end
		end
	
	end

	function input.draw()

	end

	function input.clear()
	
--print("clear")

		input.clear_count=10 -- ignore future msgs for a little while 
		
		for i,v in pairs(input.volatile) do -- unset anything that may have been set
			if type(v)=="boolean" then
				input.volatile[i]=false
				input[i]=false
			end
		end
	end
	
	return input
end
