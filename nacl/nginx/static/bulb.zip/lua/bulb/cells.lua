-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module("bulb.cells")

function bake(state,cells)
	local cells=cells or {}

	local cake=state.cake
	local game=cake.game	
	
	local field	=state:rebake("bulb.field")
	local drops	=state:rebake("bulb.drops")
	local score	=state:rebake("bulb.score")
	local ball	=state:rebake("bulb.ball")

	local cellbase={}
	local cellmeta={__index=cellbase} -- a meta table for cells

	function cells.state_change()

	-- handle state changes

		if cells.state_next then
		
			if cells.state and cells.state.clean then
				cells.state.clean()
			end
			
			if type(cells.state_next)=="string" then	 -- change by name
				cells.state_next=cells.states[cells.state_next]
			end

			cells.state_last=cells.state
			cells.state=cells.state_next
			cells.state_next=nil
			
			if cells.state and cells.state.setup then
				cells.state.setup()
			end
			
		end
		
	end

	cells.states={}
	cells.states.wait={
		setup=function()
			cells.frame=cells.frame+1 -- frame bump when we enter the wait state
			cells.chain=0 --remove chain bonus
		end,
		update=function()
		end,
	}
	cells.states.animate={
		setup=function()
		end,
		update=function() -- animate the cells before continuing
			local finished=true
			for c in cells.all() do
				if c.animate then
				
					c.animate=c.animate-1
					
					c.px=c.px+c.vx
					c.py=c.py+c.vy
				
					if c.animate<=0 then -- last one
						c.animate=nil -- clear flag
						c.vx=nil
						c.vy=nil
						c.px=c.bx
						c.py=c.by
					else
						finished=false
					end
				end
			end
			if finished then
				cells.state_next="fall"
			end
		end,
	}
	cells.states.fall={
		setup=function()
		end,
		update=function()
		
			cells.state_next="clear" -- if there is nothing to fall then do this next
							
			for c in cells.all() do
				if c.id~=0 then -- this cell is solid
					for cb in c:bottoms() do
						if cb.id==0 then -- this cell must fall down
--print("fall")
							cb.id,c.id=c.id,cb.id -- our new cell
							cb.rz,c.rz=c.rz,cb.rz -- our new cell
							
							cb.active=cells.frame -- is now active as we moved to it
--							c.active=0 -- and this is not active anymore
							cb.animate=6
							cb.px=c.bx -- from here
							cb.py=c.by
							cb.vx=(cb.bx-c.bx)/cb.animate -- by this each frame
							cb.vy=(cb.by-c.by)/cb.animate
							cells.state_next="animate" -- need to animate some cells
							break
						end
					end
				end
			end
			
		end,
	}
	cells.states.clear={
		setup=function()
		end,
		update=function()
		
			local linkmap={}
		
			local spreading=true
			while spreading do
				spreading=false
				for c in cells.all() do
					if c.active==cells.frame and c.id~=0 then -- this cell is active so may clear
						for cn in c:neighbours() do
							if (cn.id==c.id) and (c.id~=0) then
								cn.active=c.active -- the activeness spreads

								if not c.links then -- make a new linkmap
									c.links=c.links or {c=c}
									linkmap[c.links]=#linkmap+1
									linkmap[#linkmap+1]=c.links
								end
								
								if cn.links then -- need to merge links
									if cn.links == c.links then -- already merged
									else
										spreading=true
										if linkmap[c.links] < linkmap[cn.links] then -- must merge towards the oldest
											for i,v in pairs(cn.links) do
												c.links[i]=v
											end
											cn.links=c.links -- merged now so share table
										else
											for i,v in pairs(c.links) do
												cn.links[i]=v
											end
											c.links=cn.links -- merged now so share table
										end
									end
								else -- just add to our links
									spreading=true
									cn.links=c.links
									c.links[cn]=cn -- added
								end
							end
						end
					end
				end
			end

			local clearcount=0

			for c in cells.all() do
			
				if c.links then
				
					local count=0 for i,v in pairs(c.links) do count=count+1 end
					
--print(c.idx,"count",count)

					local x=0
					local y=0

					if count>=3 then -- can kill

						for i,v in pairs(c.links) do
							x=x+v.px
							y=y+v.py
							drops.newdrop(v)
							v.id=0 -- remove
							clearcount=clearcount+1
							v.links=nil -- finished with links
						end
--print("chain ="..cells.chain)
						local num=(cells.chain+1)*(2^(3+count-1))
						score.add(num)
						score.newfloater(x/count,y/count,num)
						ball.dip=ball.dip-num/10
						if ball.dip<0 then ball.dip=0 end
					end
					
					c.links=nil -- always finished with links
				end
				
			end
			
			if clearcount==0 then
				cells.state_next="wait" -- all done, nothing left to clear
			else
				cells.state_next="fall" -- go back to doing nothing
				cells.chain=cells.chain+1
			end
		end,
	}

	function cells.loads()
	end
	
	function cells.setup()


		cells.frame=0

		cells.loads()

		cells.cw=6
		cells.ch=14
		
		local ldat=require("bulb.levelsdata").levels[2].map
		cells.tab={}
		for i=0,(cells.cw*cells.ch)-1 do
			cells.tab[i]=cells.newcell(i)
			cells.tab[i].id=ldat[i+1] or 0
		end
		
		cells.state_next="wait"
		cells.state_change()
	end


	function cells.update()
	
		cells.state_change()	
		if cells.state and cells.state.update then cells.state.update() end	
	
	end

	function cells.draw()
	
		local bulbs=cake.sheets.get("bulbs")

		for i=0,(cells.cw*cells.ch)-1 do
			local v=cells.tab[i]
		
			if v.id~=0 then -- 0 is nothing
--				cake.blit("bulbs",nil,
--					field.px+v.px-(game.bulb_size/2) , field.py+v.py-(game.bulb_size/2),
--					game.bulb_size*(v.id-1),0,game.bulb_size,game.bulb_size )

				bulbs:draw(v.id,field.px+v.px, field.py+v.py , v.rz )
			end
		end

	end


	function cells.newcell(idx)

		local cell={}
		setmetatable(cell,cellmeta)
		
		cell.cake=cake
		cell.idx=idx
		cell.id=0
		cell.cx=idx%cells.cw
		cell.cy=(idx-cell.cx)/cells.cw
		
		cell.ax=0
		if cell.cy%2==1 then cell.ax=game.unit/2 end
		
		cell.bx=cell.ax+(cell.cx+1)*game.unit + (game.unit/2)
		cell.by=math.floor((cells.ch)*game.unit*12/16) - ( (cell.cy)*math.floor(game.unit*12/16) ) + (game.unit/2)
		
		cell.px=cell.bx
		cell.py=cell.by
		
		cell.rz=0

		return cell
	end

	-- convert an x,y pixel position into its closest cell cx,cy indexs
	-- notably the x,y is upside down in cells as we start at the bottom and
	-- in pixels we start at the top, this pixel is assumed to be relative to the field
	function cells.pxy_to_cxy(px,py)
		
		local nx=(px)-game.unit
		local ny=((cells.ch)*game.unit*12/16) - (py)

		local cy=math.floor(ny/(game.unit*12/16))
		local bx=0
		if cy%2==1 then bx=game.unit/2 end -- shift in odd rows
		local cx=math.floor((nx-bx)/(game.unit))
		
		return cx,cy
	end

	-- turn a cell location, cx,cy into a real pixel location px,py
	function cells.cxy_to_pxy(cx,cy)

		local bx=0
		if cy%2==1 then bx=game.unit/2 end
		
		local px=bx+(cx+1)*game.unit
		local py=math.floor((cells.ch)*game.unit*12/16) - ( (cy)*math.floor(game.unit*12/16) )

		return px+(game.unit/2),py+(game.unit/2)
	end


	-- turn a cell location into that cell or nil if out of bounds
	function cells.get_cell(cx,cy)
		if cx<0 then return nil end
		if cx>=cells.cw then return nil end
		if cy<0 then return nil end
		if cy>=cells.ch then return nil end
		local c=cells.tab[cx+(cy*cells.cw)]
		return c
	end

	-- iterate through all the cells
	function cellbase.all()
		local len=#cells.tab
		local i=0
		return function()
			if i>=len then return nil end -- no more edges
			local c=cells.tab[i]
			i=i+1
			return c
		end
	end
	cells.all=cellbase.all -- via cell or cells

	-- iterate through all the neightbours of this cell
	function cellbase.neighbours(cell)
		local len=#cells.tab
		local n_x_look={  0 ,  1 , -1 ,  1 ,  0 ,  1 }
		local n_y_look={  1 ,  1 ,  0 ,  0 , -1 , -1 }
		if cell.cy%2==0 then
		      n_x_look={ -1 ,  0 , -1 ,  1 , -1 ,  0 }
		end
		local i=1
		return function()
			while i<=6 do
				local c=cells.get_cell(cell.cx+n_x_look[i],cell.cy+n_y_look[i])
				i=i+1
				if c then
					return c
				end
			end
			return nil -- no more edges
		end
	end

	-- iterate through all the bellow neightbours of this cell
	function cellbase.bottoms(cell)
		local len=#cells.tab
		local n_x_look={  0 ,  1 }
		local n_y_look={ -1 , -1 }
		if cell.cy%2==0 then
		      n_x_look={ -1 ,  0 }
		end
		local i=1
		return function()
			while i<=2 do
				local c=cells.get_cell(cell.cx+n_x_look[i],cell.cy+n_y_look[i])
				i=i+1
				if c then
					return c
				end
			end
			return nil -- no more edges
		end
	end
	return cells
end
