-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")


module("bulb.drops")

function bake(state,drops)
	local drops=drops or {}

	local cake=state.cake
	local game=cake.game
	
	local ball	=state:rebake("bulb.ball")
	local field	=state:rebake("bulb.field")

	function drops.loads()
	end
	
	function drops.setup()
		
		drops.tab={}
		
	end
	
	function drops.update()
		
		for i=#drops.tab,1,-1 do local v=drops.tab[i]
			ball.fizix(v)
			if v.py > game.unit*20 then
				table.remove(drops.tab,i)
			end
		end
		
	end

	function drops.draw()
	
		local bulbs=cake.sheets.get("bulbs")

		for i,v in ipairs(drops.tab) do
--			cake:blit("bulbs",nil,
--				field.px+v.px-(game.bulb_size/2) , field.py+v.py-(game.bulb_size/2),
--				game.bulb_size*(v.id-1),0,game.bulb_size,game.bulb_size )

				bulbs:draw(v.id,field.px+v.px, field.py+v.py , v.rz )
		end
		
	end

	function drops.newdrop(cell)

		local drop={}
		
		drop.id=cell.id
		
		drop.px=cell.px
		drop.py=cell.py
		drop.rz=cell.rz
		
		drop.vx=0
		drop.vy=-5

		drops.tab[#drops.tab+1]=drop
		
		return drop
	end
	
	return drops
end
