-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module("bulb.game_play")

function bake(state,play)
	local play=play or {}
	
	local cake=state.cake
	local game=cake.game
	
	cake.game.play=play
	
	local mods={} for i,n in ipairs{
		"bulb.input",
		"bulb.levels",
		"bulb.field",
		"bulb.cells",
		"bulb.ball",
		"bulb.drops",
		"bulb.score",
	} do mods[i]=state:rebake(n) end
	
	function play.loads()
		cake.fonts.loads({"Vera"})
		
		
		for i,v in ipairs(mods) do
			if v.loads then v.loads() end
		end
		
	end
	
	function play.setup()
	
		play.loads()
			
		for i,v in ipairs(mods) do
			if v.setup then v.setup() end
		end

	end

	function play.clean()

		for i,v in ipairs(mods) do
			if v.clean then v.clean() end
		end

	end


	function play.update()

--[[
	local str=cake.sounds.strs[1]
	if not str.oggs then
		str.ogg_loop=true
		str.state="play_queue"
		str.oggs={
			"test",
		}
	end
]]

		for i,v in ipairs(mods) do
			if v.update then v.update() end
		end
		
	end

	function play.draw()
		
		for i,v in ipairs(mods) do
			if v.draw then v.draw() end
		end

	end
	
	return play
	
end
