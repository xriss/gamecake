-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")


module("bulb.field")

function bake(state,field)
	local field=field or {}
	
	local cake=state.cake
	local game=cake.game
	
	function field.loads()
		cake.images.loads({
			"game",
		})
	end
	
	function field.setup()

		field.loads()
		
		field.hx=8.5*game.unit
		field.hy=12.5*game.unit
		field.px=math.floor((320-field.hx)+game.unit*0.25)
		field.py=math.floor((480-field.hy)+game.unit*0.5)
		
		cake.sheets.createimg("game"):chop(1,1)

	end


	function field.update()
		
	end

	function field.draw()

		cake.sheets.get("game"):draw(1,-320,-240,0,960,960)
			
	end

	return field
end
