-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local apps=apps
local win=win


local function print(...) _G.print(...) end

local wstr=require("wetgenes.string")

module("bulb.score")

function bake(state,score)
	local score=score or {}

	local cake=state.cake
	local game=cake.game
	local field	=state:rebake("bulb.field")
	
	local canvas=cake.canvas

	function score.loads()
	end
	
	function score.setup()
		
		score.tab={}
		
		score.num=0
		score.disp=0
		score.count=0
		score.per=0
		
	end
	
	function score.update()
		
		for i=#score.tab,1,-1 do local v=score.tab[i]
--			ball.fizix(v)
			v.px=v.px+v.vx
			v.py=v.py+v.vy
			v.alpha=v.alpha-(1/200)
			if v.alpha <= 0 then
				table.remove(score.tab,i)
			end
		end
		
		if score.disp+100<=score.num then
			score.disp=score.disp+100
		elseif score.disp+10<=score.num then
			score.disp=score.disp+10
		elseif score.disp+1<=score.num then
			score.disp=score.disp+1
		end
		
	end

	function score.draw()




		canvas.font.set(cake.fonts.get("Vera"))
		canvas.font.set_size(32,0)
		if score.count>0 then
			score.per=math.floor(score.num/score.count)
		end
--		local s=string.format("%d / %d = %d",score.num,score.count,score.per)
		local s=string.format("%d",score.disp)
		local sw=canvas.font.width(s)

		cake.gl.Color(0,0,0,1)	
		canvas.font.set_xy(160-(sw/2)+2,24+2)
		canvas.font.draw(s)
		
		cake.gl.Color(1,1,1,1)	
		canvas.font.set_xy(160-(sw/2),24)
		canvas.font.draw(s)
		

		for i,v in ipairs(score.tab) do
			cake.gl.Color(v.alpha,v.alpha,v.alpha,v.alpha)	
			canvas.font.set_xy(v.px+field.px-(canvas.font.width(v.str)/2),v.py+field.py-8)
			canvas.font.draw(v.str)
		end

	end

	function score.add(num)
		score.num=score.num+num
	end
	
	function score.newfloater(x,y,num)

		local v={}
		
		v.px=x
		v.py=y
		
		v.num=num
		v.str=string.format("%d",num)
		
		v.vx=0
		v.vy=-2
		
		v.alpha=1

		score.tab[#score.tab+1]=v
		
		return v
	end
	
	return score
end
